package com.genove.learning

data class Course(
    val id: Int,
    val title: String,
    val description: String,
    val category: String,
    val level: String,
    val hours: Int,
    val keywords: List<String> = emptyList()
)

object DemoData {
    const val ALL = "Toutes"
    const val DEV = "Développement"
    const val AI = "Intelligence artificielle"
    const val DATA = "Data & BI"
    const val BUSINESS = "Business"

    val courses = listOf(
        Course(1, "Développement Android avec Kotlin", "Créez des applications Android natives avec Kotlin et XML Views.", DEV, "Intermédiaire", 32, listOf("android", "kotlin", "mobile")),
        Course(2, "Développement Web avec React", "Construisez des interfaces web modernes avec React.", DEV, "Intermédiaire", 28, listOf("web", "react", "javascript")),
        Course(3, "Introduction à l'intelligence artificielle", "Comprendre les concepts clés de l'IA et ses usages.", AI, "Débutant", 12, listOf("ia", "ai")),
        Course(4, "Data Analytics avec Power BI", "Analysez et visualisez vos données avec Power BI.", DATA, "Intermédiaire", 20, listOf("power bi", "dashboard", "analytics")),
        Course(5, "Bases de données SQL", "Maîtrisez les requêtes SQL et la modélisation relationnelle.", DATA, "Débutant", 18, listOf("sql", "database")),
        Course(6, "Python pour les débutants", "Apprenez la programmation avec Python pas à pas.", DEV, "Débutant", 16, listOf("python", "programmation")),
        Course(7, "Machine Learning : fondamentaux", "Les bases du machine learning supervisé et non supervisé.", AI, "Avancé", 30, listOf("ml", "machine learning")),
        Course(8, "Business Intelligence", "Concevez une démarche BI de la collecte à la décision.", BUSINESS, "Intermédiaire", 22, listOf("bi", "décisionnel", "entrepôt"))
    )

    fun byId(id: Int) = courses.firstOrNull { it.id == id }
}
