package com.genove.learning

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.genove.learning.databinding.ItemCourseBinding

class CourseAdapter(private val onClick: (Course) -> Unit) :
    ListAdapter<Course, CourseAdapter.VH>(Diff) {

    inner class VH(val b: ItemCourseBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCourseBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = getItem(position)
        val ctx = holder.b.root.context
        holder.b.tvTitle.text = c.title
        holder.b.tvBadge.text = c.level
        holder.b.tvSubtitle.text = "${c.category} · ${c.level}"
        holder.b.tvDuration.text = ctx.getString(R.string.course_duration_hours, c.hours)
        val bg = when (c.category) {
            DemoData.DEV -> R.color.gl_card_blue
            DemoData.AI -> R.color.gl_card_violet
            DemoData.DATA -> R.color.gl_card_green
            else -> R.color.gl_card_orange
        }
        holder.b.artContainer.setBackgroundColor(ContextCompat.getColor(ctx, bg))
        holder.b.root.setOnClickListener { onClick(c) }
    }

    object Diff : DiffUtil.ItemCallback<Course>() {
        override fun areItemsTheSame(a: Course, b: Course) = a.id == b.id
        override fun areContentsTheSame(a: Course, b: Course) = a == b
    }
}
