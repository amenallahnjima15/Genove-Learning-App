package com.genove.learning

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.genove.learning.databinding.FragmentProfileBinding
import java.util.Calendar

class ProfileFragment : Fragment() {
    private var _b: FragmentProfileBinding? = null
    private val b get() = _b!!

    private var selectedDay = 23
    private var selectedMonth = 4 // 0-indexed (Mai)
    private var selectedYear = 1995

    private val countries = arrayOf(
        "Nigeria",
        "Tunisie",
        "France",
        "Canada",
        "Algérie",
        "Maroc",
        "Sénégal",
        "Belgique",
        "États-Unis",
        "Autre"
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentProfileBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // Bouton retour
        b.btnBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        // Changement de photo
        b.btnChangePhoto.setOnClickListener {
            Toast.makeText(requireContext(), "Sélectionnez une nouvelle photo de profil", Toast.LENGTH_SHORT).show()
        }

        // Sélecteur de date de naissance
        b.btnDateOfBirth.setOnClickListener {
            val dpd = DatePickerDialog(
                requireContext(),
                { _, year, month, dayOfMonth ->
                    selectedYear = year
                    selectedMonth = month
                    selectedDay = dayOfMonth
                    val formatted = String.format("%02d/%02d/%d", dayOfMonth, month + 1, year)
                    b.tvDateOfBirth.text = formatted
                },
                selectedYear,
                selectedMonth,
                selectedDay
            )
            dpd.show()
        }

        // Sélecteur de pays
        b.btnCountry.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Select Country/Region")
                .setItems(countries) { _, which ->
                    b.tvCountry.text = countries[which]
                }
                .setNegativeButton("Annuler", null)
                .show()
        }

        // Sauvegarder les modifications
        b.btnSaveChanges.setOnClickListener {
            val name = b.etName.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(requireContext(), "Veuillez entrer un nom", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(requireContext(), "Modifications enregistrées avec succès !", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
